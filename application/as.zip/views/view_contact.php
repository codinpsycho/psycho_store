<div class="container top-bottom-space">
    <h1>Psycho Store </h1>
    <h5>A Psychonet product</h5>
    <hr> 
    <div class="well">
    	<div class="row ">
	    	<div class="col-md-12">
	    		<h5>Feel free to email us at <a href=\"mailto:contact@psychostore.in\">contact@psychostore.in</a> in case of any queries or doubts</h5>
	    		<h5>Or Just give us a call anytime at +917387045828</h5>
	    		<h5>Or get in touch through <a class='btn btn-primary' href= <?php echo site_url('auth/saysomething') ?> >Contact Us</a><br><br><br></h5>
	    		<h4 class="molot">Address for returns</h4>
				<?php echo $return_address ?>
			</div>
		</div>
	</div>
	<a class='btn btn-primary' href= <?php echo site_url('') ?> >Return To Awesomess</a>
</div>
