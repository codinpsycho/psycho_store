What's the Konami Code?
Hint : Let google do the thinking and dont use spaces or arrows, only letters .

