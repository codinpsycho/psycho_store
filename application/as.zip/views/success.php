<br> All right minions, theres work to do, theres stuff to create, people are counting on us, gamers and geeks have high hopes from us and we need to deliver. So stop hunting for bananas and get to work.<br><br>
For laymans (seriously, what are you doing here) : Your order has been placed and is up for processing. We do our best to provide you with quality stuff as quickly as possible. A mail has been sent to you confirming the same along with order details.<br><br>
We hope you had a pleasant time exploring our realm, please let us know your experience.
<a class="btn btn-primary"href=<?php echo site_url('auth/saysomething')?> >Feedback</a>
<p>Also, following and talking about us on social media makes our minions very happy and more efficient. You should try doing that.</p>
<div class="row">
	<div class="col-md-12">		
		<ul class="nav nav-pills">
	    	<li>
	    		<a target="_blank" href="https://www.facebook.com/psychostorein"><i class="navbar-btn fa fa-2x fa-facebook"></i></a>
	    	</li>
	    	<li>
	    		<a target="_blank" href="https://twitter.com/psychostorein"><i class="navbar-btn fa fa-2x fa-twitter"></i></a>
	      	</li>
	      	<li>
	    		<a target="_blank" href="http://instagram.com/psychostore.in"><i class="navbar-btn fa fa-2x fa-instagram"></i></a>
	      	</li>
		</ul>		
	</div>
</div>
<a class= "btn btn-default" href= <?php echo site_url(''); ?> >Continue Shopping</a>

