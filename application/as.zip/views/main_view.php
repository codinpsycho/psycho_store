<!DOCTYPE html>
<html>
	<?php echo $intro_signature?>
<head>
	<?php echo $header?>
	<?php echo $external_scripts ?>
</head>
<body>
	<?php echo $custom_events ?>	
	<?php echo $body?>
	<?php echo $footer?>
	<?php echo $event_tracking ?>
	
</body>

</html>