<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><title><?php echo $username?>, the journey begins!</title></head>
<body>
<div style="max-width: 800px; margin: 0; padding: 30px 0;">
<table width="80%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="5%"></td>
<td align="left" width="95%" style="font: 13px/18px Arial, Helvetica, sans-serif;">
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues, <?php echo $username?>!</h2>
Acme was pretty impressed but still she said "You know you are not the first person who broke the loop?". Few days back I didn't even know what loop she was talking about and what in the world was happening with me. The year was 2021, the study of  neuroscience was on the rise, quoted as the next big thing for the evolution of humanity, more control over your brain was the fad. Though few people knew it from the start of the ages that our life is nothing but just a struggle to tame our mind, if only people could  slow down and realize it. I was not going to let this pass, let them get away with what they did to me. The humanity has now advanced enough to control the human mind with special neurotic signals and devices, depression was on the rise and this study was being done extensively to curb it, rewire the depressed mind to feel happy again. But as always everything has its downsides also. Once we wrapped our mind over the fact that we can manipulate a person's mind by targeting special parts of the brain, there were no bounds for the humans imagination as to what else can be achieved with this new discovery, specifically to control and manipulate the mind to satisfy their will. Motivating employees of large corporations was one of the most widespread usage along with curbing depression and spreading so called happiness, obviously simulating the mind similar to drug abuse was the most common illegal usage. So basically this is what I understood from acme, instead of now putting people into actual prisons, there are now these illegal prisons in various parts of the world, known as mind prisons, you basically trap the people into a virtual loop and they keep living it on and on and in real life they are just lying in a bed like being in a coma and if you don't feed their body they just gradually die. Now they don't control what will get simulated inside the mind, it obviously differs from people to people and depends on the person's life, his feelings and emotions and a ton of other factors. So this was the loop I was in, waiting for the call, getting weapons and going on a rescue mission. But still there are a ton of unanswered questions that they need to answer, but I was lucky enough to be able to break it, but one thing was obviously, things are just getting started.
<br />
<br />
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues on your next order!</h2>
<br />
<?php  echo $this->load->view('email/signature', null, True) ?>;
</td>
</tr>
</table>
</div>
</body>
</html>