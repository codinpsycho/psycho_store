<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><title><?php echo $username?>, the journey begins!</title></head>
<body>
<div style="max-width: 800px; margin: 0; padding: 30px 0;">
<table width="80%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="5%"></td>
<td align="left" width="95%" style="font: 13px/18px Arial, Helvetica, sans-serif;">
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues, <?php echo $username?>!</h2>
So there I was planning my next moves, one thing was certain it had to be different from the last three times. I wasnt sure what kind of thing I was in, so i was just following this legendary theory which goes something like this "in order to achieve soemthing you have never had, you need to do something that you have never done before". I was just doing some quick bug fixes to my code, which is one of the things that helps me calm down my nerves and lets me get lost in the now. The thing that I have always loved about coding is the god like feeling that it gives you. It's like you have these fundamental blocks like int float char etc and when you combine them in different combinations or ways you can literally build anything that you can imagine, obviously I am simplifying it way too much, so dont get carried away. The code was ready now, I transferred it to the device and i had no time for testing so it had to be tested right in the battlefield now. So the next step was to finalise the inventory, there was a specific way to order each inventory item, everything had a special code and order that needs to be followed at Big Bad Joe's. If you mess up your order theres no refund policy as well so you need to  memorise them very carefully. But well after a certain time you tend to develop a pattern and kidn of order the same inventory everytime. But since this time it was something new for me i memeorised the difeerent codes I required carefully, took a good hard look at myself in the mirror and left for the Big Bad Joes. Shit was about to get real as they used to say back in the good old days.
<br />
<br />
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues on your next order!</h2>
<br />
<?php  echo $this->load->view('email/signature', null, True) ?>;
</td>
</tr>
</table>
</div>
</body>
</html>