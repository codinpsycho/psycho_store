<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><title><?php echo $username?>, the journey begins!</title></head>
<body>
<div style="max-width: 800px; margin: 0; padding: 30px 0;">
<table width="80%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="5%"></td>
<td align="left" width="95%" style="font: 13px/18px Arial, Helvetica, sans-serif;">
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story begins, <?php echo $username?>!</h2>
The sound was coming from the washroom, like someone was peeing which is infact quite similar to a semi-open tap. But since i live alone, this meant that i must have probably left the tap open, so i went inside to close it as i dont like to waste natural resources. But it turned out that the tap was closed but the sound was coming from the flush which was getting refilled, because damnit i had just peed and flushed and also because i had drunk more than i should have. The phone should have rang almost an hour before now, it was very rare for things to not go as planned. I think i had a little more alcohol than i should have, given the importance of work involved and now since the phone didn't ring as it was supposed to, i was getting even more worried as to what should i do now. Usually in these cases we are just supposed to wait and not contact anyone, as i was thinking about opening another bottle of beer, the phone rang. The first thing i heard was "Pizza or Burger", it was a standard question, pretty normal, they just want to know if you are a pizza guy or a burger guy, that is to say "How do you like to do your work, pizza way or the burger way?" Actually this thing goes way way back to one night, when they dont know how, came to the conclusion that pizza is kind of neat, like it doesnt spill sauces here and there, it keeps your surrounding reasonable clean, its thin, you can cut it into pieces and eat it sensibly, it doesnt get your mouth dirty, but the burger, it spills sauce when you pick it up or squeeze it and more the number of patties inside it, more difficult to handle it, it can get the sides of your mouth pretty dirty expecially if you have a beard or a moustache, its difficult to actually dip it into tomato ketchup satisfactory and dont even get me started when some tomato or god forbid patty just pops out of it. Although in real life i definitely prefer burgers, but in work i always go the pizza way, not because i care much about the cleaners, but i just dont want much blood on my own clothes. But this night, i chose to go the burger way.
<br />
<br />
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues on your next order!</h2>
<br />
<?php  echo $this->load->view('email/signature', null, True) ?>;
</td>
</tr>
</table>
</div>
</body>
</html>