<?php echo $username?>, Psycho Store says "Thank You"</h2>

We hope that you have fallen in love with your Psycho Store merchandise.
Just wanted to say a big 'Thank you' for ordering from us.
Do leave us some feedback at psychostore.in/auth/saysomething. We would love to know what you think of us and how we can improve.

Steps to unlock discount and earn cheat codes
1. Show off your gaming/geeky side with your psychostore merchandise on social media.
2. Dont forget to tag us.

Leave the rest to us, we will make sure that you unlock some good discount on your next order.


If there is any query/concern, do contact us at contact@psychostore.in

<?php  echo $this->load->view('email/signature', null, True) ?>;