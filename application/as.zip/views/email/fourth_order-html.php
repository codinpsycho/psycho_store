<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><title><?php echo $username?>, the journey begins!</title></head>
<body>
<div style="max-width: 800px; margin: 0; padding: 30px 0;">
<table width="80%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="5%"></td>
<td align="left" width="95%" style="font: 13px/18px Arial, Helvetica, sans-serif;">
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues, <?php echo $username?>!</h2>
From the corner of my eye I could see some stoners munching on their burgers and enjoying pink floyd in the background, I was always of the opinion that trippy ambience combined with pink floyd is what keeps this place going and yes also the fact that this is an illegal den for weapon gathering for different gangs. Basically you just get a special token (kind of what you get at metro stations) along with your food which you have to give at the back alley to get your weapons. What weapons you will get from the token is encoded inside it, the inventory master scans the token and hands you the weapons, simple as that. At one point I guess gangs just got tired of smuggling weapons and handling them for their members, so this tech savvy company comes up with this solution and everyone just outsourced their headache to them. The background details are obviously much more intricate and complicated than this. I quietly finished my food at a corner, got my weapons at the back alley and continued on bike. It had started drizzling and frankly speaking I never liked getting wet, it just makes your clothes so heavy and makes your movement slow especially if you are wearing jeans. So I accelerated and reached the destination marked on my map which obviously was an old warehouse, it always has to be an old rotting building or a warehouse, like no one, literally no one can think of a better place to stage a shootout or hold a hostage. I was not aware of the person I was about to set free but apparently it was someone very important, but truth be told no one could have prepared me for what was coming. The whole warehouse was empty except for just one guy holding a gun to the hostage's head who was tied up in a chair. He didn't yell at me  or anything, was calm as a shaolin monk as though he was expecting me , but everything was about to change as I saw who the hostage was and all I could see was myself tied up in the chair. I was literally seeing myself there as if I was watching things happening in another dimension through a portal, but no this was for real, actually real. All I could hear was the sound of the water, I thought it was the rain but no, the sound was coming from the washroom, like someone was peeing which is in fact quite similar to a semi-open tap. But since I live alone, this meant that I must have probably left the tap open, so I went inside to close it as I don't like to waste natural resources.
<br />
<br />
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues on your next order!</h2>
<br />
<?php  echo $this->load->view('email/signature', null, True) ?>;
</td>
</tr>
</table>
</div>
</body>
</html>