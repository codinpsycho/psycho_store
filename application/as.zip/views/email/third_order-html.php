<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><title><?php echo $username?>, the journey begins!</title></head>
<body>
<div style="max-width: 800px; margin: 0; padding: 30px 0;">
<table width="80%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="5%"></td>
<td align="left" width="95%" style="font: 13px/18px Arial, Helvetica, sans-serif;">
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues, <?php echo $username?>!</h2>
Frankly speaking I don't even remember the taste of organically grown food, once the wave of 3d printed food hit us, cooks and chefs were a gone profession or you can say they became a luxury nowdays catering only to the uber rich class of the society. I would put all the blame on our quest to get things done as quickly as possible, automate as much as possible and get more time to do things that actually matters, so they said, which basically means to become a source where the top uber class can feed us more and more advertisements and make us want things to supress our sadness, momentarily obviously. Depression and crime was all time high nowdays because people just didn't knew what to do with their new found time. ALthough this led to a new breed of profession the so called agents of happiness that guarante you a happy life. Life was actually pretty simple back in those days. Anyway I can't let my mind get distracted with all these thoughts now, big bad joes was just around the corner, I parked my bike which was quite a piece of antique nowdays, a person like me shouldn't be driving such a thing that attracts so many eyeballs. There's no one actually named Joe there, I will never understand where they come up with such names, usually I approach a person who goes by the name of timedemon there, which basically is his gaming alias and he is from India, back in those days, they all were just dying to reach here, but not anymore, nowdays this place doesnt have that magnetic power to attract people but frankly I find them much better and trustworthy than others. He is the point of contact here, but majority of the time we don't need to interact with anyone, each food item has a special code, all we have to do is just enter the code in the vending machine and swipe the card for payment and the order is done. Now certain combination is registered for specific weapons, so I entered the codes I had memorised and waited for the confirmation.
<br />
<br />
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;">The story continues on your next order!</h2>
<br />
<?php  echo $this->load->view('email/signature', null, True) ?>;
</td>
</tr>
</table>
</div>
</body>
</html>