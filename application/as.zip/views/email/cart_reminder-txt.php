<?php echo $username?>, Psycho Store remembers!</h2>

You might have forgotten us, but we never forget those who love our products. So as a token of love here's a cheat code specially for you that will unlock some discount.

left_left_up_down

Awesomness is waiting for your in you cart. Go and get it and dont forget to apply this special cheat code.

http://psychostore.in/cart

<?php  echo $this->load->view('email/signature', null, True) ?>;