<div class="container top-bottom-space">
	<h1>Message</h1>
	<hr>
	<div class="well">
		<?php echo $message; ?>
	</div>
</div>