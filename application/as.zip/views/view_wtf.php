<canvas id = "canvas_colors">
</canvas>	
<script type="text/javascript" src= <?php echo site_url('scripts/audio.js')?> ></script>