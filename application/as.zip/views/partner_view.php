<div class="container top-bottom-space">
    <h1> Inventory </h1>
    <hr>
    <div class="well">
        <div class="row ">
            <div class="col-md-12">
                <?php echo $products_table; ?>
            </div>
        </div>
    </div>
</div>
