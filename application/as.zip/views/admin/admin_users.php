<div class="container top-bottom-space">  
    <h1> Users
    	<span class="pull-right navbar-text"> <small><?php echo $num_users?> users(s) </small></span>
    </h1>
    <hr>
    <div class="well">
    	<div class="row ">
	    	<div class="col-md-12">
	    		<?php echo $users_table; ?>
			</div>
		</div>
	</div>
</div>
