<div class="row top-bottom-space">
	<div class="col-md-12">
	  <h3>#<?php echo $tag_name ?></h3>
	  <h5>Show off your geeky side. Tag your loot #<?php echo $tag_name ?> on instagram to get featured here.</h5>
	  <hr>
	  <div id="instafeed"></div>
	</div>
</div>