<h3>Our belief</h3><p>You probably would be thinking why the word "Psycho" in a Gaming Merchandise store. Well it actually has to do with a problem that we have, "Our Belief" that is getting increasingly obsessed with something that we are passionate about. Giving it all that we have and actually going that extra mile when everyone else's common sense says that it's the wrong direction. Did you ever have that feeling that whatever you were doing, your mind was always stuck on that one thing, that one thing which kept knocking on the back door of your mind.
We call that being in a state of psychoness, in which you feel about something so deep from your heart that you take absurd decisions to get it through, no matter what it takes and whats the cost. If you can relate, then just give us a shout I am sure our frequencies would match.
In short we have that crazy streak in us for whatever we decide to do. <br>In Hindi we say "keeda hona chahiye kisi cheez ke liye". We just replaced keeda with psycho and we are proud to say that we have that in us.<br>
Whatever we do, we do with that crazy streak, whoever we work with, we just try to look for that crazy streak in them as well.
<br><br>Oh by the way, you were asking</p> <h3>who are we?</h3> <p>We are the people who are working hard to create Psycho Store the biggest and the most badass merchandise brand for the gaming and geek community of earth (other planets can wait for now).<br></p>
<h3><small>What is</small> <> by Codinpsycho ?</h3>
<div class="row">
	<div class="col-md-12 text-center">
		<img class="circular-pic" width="250" src= <?php echo site_url('images/intro_pic.jpg')?> >
		<p>It means all this crazy stuff was thought, designed and programmed by this guy above wandering some hills in india, who calls himself codinpsycho, god knows why. Also he open sourced this website's code, if any programmer out there wants to use. Get in touch with him and praise him, that would make him happy which in turn will make him do more creative stuff.<br></p>
		<div class="col-md-2">
			<h5><a target='_blank' href="https://codinpsycho.com"><i class="fa fa-2x fa-globe"></i> </a></h5>
		</div>
		<div class="col-md-2">
				<h5><a target='_blank' href="https://twitter.com/codinpsycho"><i class="fa fa-2x fa-twitter"></i></a></h5>
		</div>
		<div class="col-md-2">
			<h5><a target='_blank' href="https://www.facebook.com/codinpsycho"><i class="fa fa-2x fa-facebook"></i> </a></h5>
		</div>
		<div class="col-md-2">
			<h5><a target='_blank' href="https://github.com/codinpsycho"><i class="fa fa-2x fa-github-alt"></i></h5></a>
		</div>
		<div class="col-md-2">
			<h5><a target='_blank' href="https://codinpsycho.tumblr.com"><i class="fa fa-2x fa-tumblr"></i></h5></a>
		</div>
		<div class="col-md-2">
			<h5><a target='_blank' href="https://instagram.com/psychostore.in"><i class="fa fa-2x fa-instagram"></i></h5></a>
		</div>		
	</div>
</div>
<br>
<br>
<br>
Kudos to these kickass human beings: 
<a target='_blank' href="https://twitter.com/mdo">@mdo</a> and <a target="_blank" href="https://twitter.com/fat">@fat</a> for <a target="_blank" href="https://getbootstrap.com/">Bootstrap</a>,
guys at <a target='_blank' href="http://ellislab.com/">Ellis Lab</a> for <a target='_blank' href="https://github.com/EllisLab/CodeIgniter/">CodeIgniter</a></p>
<p><br>P.S : He also wrote all that stuff you just read, including this line.</p>
