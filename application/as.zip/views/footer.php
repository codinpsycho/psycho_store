    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-4 footer-col">
            <h4 class=" molot">Social</h4>
            <ul class="nav nav-stacked ">
              <li>
                <h5>
                  <span class=''>
                    <iframe src="http://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fpsychostorein&layout=button_count&action=like&show_faces=false&share=true&height=21&appId=601282446622582" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:21px; width:135px;" allowTransparency="true">
                    </iframe>
                  </span>
                </h5>
              </li>
              <li>
                <h5>
                  <span class=''>
                    <a href="https://twitter.com/psychostorein" class="twitter-follow-button" data-show-count="true" data-lang="en" show-screen-name="true" data-size="small"></a>
                  </span>
                </h5>
              </li>
              <li>
                <h5>
                  <span class=''>
                    <style>.ig-b- { display: inline-block; }
                    .ig-b- img { visibility: hidden; }
                    .ig-b-:hover { background-position: 0 -60px; } .ig-b-:active { background-position: 0 -120px; }
                    .ig-b-v-24 { width: 137px; height: 24px; background: url(//badges.instagram.com/static/images/ig-badge-view-sprite-24.png) no-repeat 0 0; }
                    @media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (min--moz-device-pixel-ratio: 2), only screen and (-o-min-device-pixel-ratio: 2 / 1), only screen and (min-device-pixel-ratio: 2), only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx) {
                    .ig-b-v-24 { background-image: url(//badges.instagram.com/static/images/ig-badge-view-sprite-24@2x.png); background-size: 160px 178px; } }</style>
                    <a href="http://instagram.com/psychostore.in?ref=badge" class="ig-b- ig-b-v-24"><img src="//badges.instagram.com/static/images/ig-badge-view-24.png" alt="Instagram" /></a>
                  </span>
                </h5>
              </li>
              <li>
                <h5>
                  <span class=''>
                    <iframe src="http://ghbtns.com/github-btn.html?user=codinpsycho&type=follow&count=false"allowtransparency="true" frameborder="0" scrolling="0" width="150" height="30"></iframe>
                  </span>
                </h5>
              </li>
            </ul>
          </div>
          <div class="col-md-4 footer-col">
            <h4 class=" molot">Company</h4>
            <ul class="nav nav-stacked ">
              <li>
                <a href= <?php echo site_url('contact')?> >Contact</a>
              </li>
              <li>
                <a href=<?php echo site_url('about')?>>Who are We</a>
              </li>
              <li>
                <a href= <?php echo site_url('shipping_returns')?> >Shipping and Returns</a>
              </li>
              <li>
                <a href= <?php echo site_url('media')?> >Media</a>
              </li>
              <li>
                <a target="_blank" href= "http://psychostore.in/blog" >Psycho Realm</a>
              </li>
              <li>
                <a href= <?php echo site_url('coupon_partners')?> >Coupon Partners</a>
              </li>
              <li>
                <a href= <?php echo site_url('psycho_offers')?> >Discount Offers</a>
              </li>              
              <li>
                <a href= <?php echo site_url('student_discount')?> >Student Discount</a>
              </li>
            </ul>
          </div>
          <div class="col-md-4 footer-col">
            <h4 class="molot">Newsletter</h4>
              <form class="form" method = "post" action=<?php echo site_url('subscribe')?>>
                <div class="input-group">
                  <input type="email" name="subscribe_email" class="form-control input-sm" placeholder="you@email.com">
                  <span class="input-group-btn"><button class="btn btn-primary btn-sm" type="submit">Subscribe</button></span>
                </div>
              </form>
              <p><small>Be the first to know when new loot arrives</small></p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <a target="_blank" class="molot pull-right" href= <?php echo site_url('wtf') ?> ><small>wtf.</small></a>
            <hr>
            <h5><i class="fa fa-angle-left"></i> <i class="fa fa-angle-right"></i> by <a target="_blank" href="http://codinpsycho.com">codinpsycho</a> <span class='pull-right'>Psycho Store <?php echo date('Y') ?> &copy; All rights reserved. A Psychonet Product.</span><h5>
            <p><small>All artwork posted on this website is intended as fan art and is not purported to be official merchandise. If you have any issues regarding the artwork, please write in to us at contact@psychostore.in</small></p>
          </div>
        </div>
      </div>
    </footer>