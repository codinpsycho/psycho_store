<div class="container top-bottom-space">
    <h1>Sales Data
    </h1>
    <hr>    
    <form class="navbar-form"  method = "post" action=<?php echo site_url('sales')?>>
      <input id="start_date" name="start_date" type="date">
      <input id="end_date" name="end_date" type="date">
      <button class="btn btn-primary" type="submit" >Download GST Data</button>
    </form>
</div>
