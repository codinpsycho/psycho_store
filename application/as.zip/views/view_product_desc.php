<div class="row top-bottom-space">
<div class="col-md-12">
  <h3>Product Description</h3>
  <hr>
  <p> <?php echo $product['product_desc']; ?> </p>
</div>
</div>