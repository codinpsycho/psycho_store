
<img class="img-responsive" alt = "<?php echo $img_alt ?>" id="prod_img" src = <?php echo site_url($images[0]) ?> >