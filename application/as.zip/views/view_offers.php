<div class="container top-bottom-space">
    <h1>Offers    	
    </h1>
    <hr>
	<div class="row ">
    	<div class="col-md-4 col-sm-12 col-xs-12">
    		<div class="well">
    			<h3>Any 3 products @ flat 10% off</h3>
    			<p>code : powerup</p>
    		</div>
		</div>		
    	<div class="col-md-4 col-sm-12 col-xs-12">
    		<div class="well">
    			<h3>Any 2 posters @ 448 INR</h3>
    			<p>code : p2psycho</p>
    		</div>
		</div>
    	<div class="col-md-4 col-sm-12 col-xs-12">
    		<div class="well">
    			<h3>Any 3 posters @ 597 INR</h3>
    			<p>code : p3psycho</p>
    		</div>
		</div>
	</div>
	<a class='btn btn-primary' href= <?php echo site_url('') ?> >Return To Awesomeness</a>
</div>
