<a target="_blank" href="http://couponclue.com"><img src= <?php echo site_url('images/coupon_partners/couponclue.png')?> ></a>
<a target="_blank" href="http://www.couponrani.com/psychostore-coupons"><img src= "http://cdn.couponrani.com/assets/images/logo.png" ></a>
<a target="_blank" href="https://www.maddycoupons.in/"><img src= <?php echo site_url('images/coupon_partners/maddy-coupons.png')?> ></a>
<a target="_blank" href="http://picodi.in"><img src= <?php echo site_url('images/coupon_partners/picodi.png')?> ></a>
<a target="_blank" href="http://couponhaat.in"><img src= <?php echo site_url('images/coupon_partners/couponhaat.png')?> ></a>
<a target="_blank" href="http://www.couponzguru.com/"><img src= "http://cdn3.couponzguru.com/wp-content/uploads/logo.png" ></a>
<a target="_blank" href="https://www.coupondaddy.in/stores/psycho-store/"><img src= "https://i2.wp.com/www.coupondaddy.in/wp-content/uploads/2014/02/coupon-daddy-india-logo.png" ></a>
<a target="_blank" href="http://www.freecouponindia.in/"><img src= <?php echo site_url('images/coupon_partners/freecouponindia.png')?> ></a>