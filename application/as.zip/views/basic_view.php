<div class="container top-bottom-space">
    <h1><?php echo $heading ?> </h1>
    <hr> 
    <div class="well">
    	<div class="row">
	    	<div class="col-md-12">
	    		<p><?php echo $content ?></p>
			</div>
		</div>	
	</div>
</div>
