<p>At Psycho Store our aim is to always provide you with unique and highest quality merchandises that you have always desired for.</p>
<h3>Free Shipping all over India</h3>
<p>Its as simple as that we ship all our merchandises totally free, no minimum cost or hidden text, wether you pay us Online or Cash On Delivery everything is shipped totally free.
Some of our designs are freshly printed on order and some are kept in stock, depending on the design ordered, your merchandise will reach you in about 3-8 buisness days, given that there is no involvement of G-Man or some other force beyond our control. You can get in touch with us if you need an urgent delivery and we will do our best to speed things up, if possible. Depending on the designs and products ordered, we may also ship your order in parts, so if some itmes are missing from your order, be patient they will be coming soon in the next parcel. As of now we ship only in India.</p>
<h3> 365 days Return Policy</h3>
<p>If you recieved a defective product or we sent the wrong size or a potato instead of what you ordered, curse us and punch us in the face if you want but most importantly notify us along with your order ID at <a href="mailto:contact@psychostore.in">contact@psychostore.in</a> within 3-5 days and send us the product back whenever you can (literally 365 days) in its original condition. We will inspect the product and will do a refund or excahnge accordingly.
We will bear the shipping charges as well if it's our fault.
<br><br> If you realised just now that you dont look good in this colour or you didn't check the size chart before buying, then we will curse you, punch you in the face if we can, but sigh, we will still accept the product back and do an exchange. You will have to bear the shipping charges in this case.
<br><br> Note: In both the cases, problem should be notified within 3-5 days along with order ID at <a href="mailto:contact@psychostore.in">contact@psychostore.in</a> and returned product should be in its original condition, it should not be worn or washed, otherwise it will not be returned. Also Cash On Delivery handling charges are not refundable.
<br><br>Email us with your product id at <a href="mailto:contact@psychostore.in">contact@psychostore.in</a> and ship the product to given address
<br><br>
<h4 class="molot">Address for returns</h4>
<?php echo $ret_address ?>
<br><br>
For any other query email us at <a href="mailto:contact@psychostore.in">contact@psychostore.in</a></p>
<br>
<a class='btn btn-primary' href= <?php echo site_url('') ?> >Return To Awesomess</a>